This is the text that we will be using for our self-study
and group project.

I hoping to see you all on next meeting. Bye.
